package com.example.user.test;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    String DATABASE_NAME, TABLE_NAME;
    ListView list;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        init();
    }

    void init()
    {
        DATABASE_NAME="cooperate";
        TABLE_NAME="pay";

        boolean isOpen = openDatabase();
        if(isOpen)
        {
            Cursor cursor = excuteRawQueryParam();
            startManagingCursor(cursor);

            String[] columns = new String[]{"name","age","phone"};
            int[] to = new int[]{R.id.name, R.id.age, R.id.phone};

            SimpleCursorAdapter mAdapter = new SimpleCursorAdapter(this, R.layout.list, cursor, columns, to);
            list.setAdapter(mAdapter);

        }
    }

    private Cursor excuteRawQueryParam(){
        String SQL = "select name, age, phone "
                +" from "+TABLE_NAME
                +" where age > ?";

        String[] args ={"10"};
        Cursor c1 = db.rawQuery(SQL,args);

        return c1;
    }


    private boolean openDatabase(){

        dbHelper=new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        return true;
    }

    private void excuteRawQuery(){
        Cursor c1 = db.rawQuery("select count(*) as Total from "+TABLE_NAME,null);
        c1.moveToNext();
        c1.close();
    }



    public class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context){
            super(context, DATABASE_NAME, null, 1);
        }

        public void onCreate(SQLiteDatabase db){
            Toast.makeText(getApplication(),"generate",Toast.LENGTH_SHORT).show();

            try{
               String DROP_SQL="drop table if exits"+TABLE_NAME;
                db.execSQL(DROP_SQL);

            }catch(Exception ex){
                Log.e("Main","exception in DROP_SQL",ex);
            }

            String CREATE_SQL = "create table "+TABLE_NAME+"("
                    +" _id integer PRIMARY KEY autoincrement,"
                    +" name text,"
                    +" age integer,"
                    +" phone text)";

            try{
                db.execSQL(CREATE_SQL);

            }catch(Exception ex){
                Log.e("main","exception in CREATE_SQL",ex);
            }

            try{
                db.execSQL("insert into "+ TABLE_NAME + "(name, age, phone) values('John',20,'010-1223-1111');");
                db.execSQL("insert into "+ TABLE_NAME + "(name, age, phone) values('ohn',25,'010-1223-1111');");
                db.execSQL("insert into "+ TABLE_NAME + "(name, age, phone) values('hn',30,'010-1223-1111');");
                Toast.makeText(getApplication(),"insert",Toast.LENGTH_SHORT).show();
            }catch (Exception ex){
                Log.e("Main","exception in insert SQL",ex);
            }
        }
        public void onOpen(SQLiteDatabase db){
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

        }
    }


}
