package com.example.user.test;

import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener{

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    String DATABASE_NAME="SKIN";
    String TABLE_NAME="My_SKIN";;

    Button btn;
    Button btn2;
    Button checkDate;
    TextView[] txt;

    String water;
    String hole;
    String color;
    String winkle;
    String sebum;
    String dead_cell;
    String date;

    ProgressBar[] pro;
    ProgressDialog pd;



    Button[] day;

    EditText edit;
    String check_date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        init();
    }

    void init()
    {
     //   btn=(Button)findViewById(R.id.btn1);

        checkDate=(Button)findViewById(R.id.check);
        checkDate.setOnClickListener(this);

        day=new Button[7];
        day[0]=(Button)findViewById(R.id.day1);
        day[1]=(Button)findViewById(R.id.day2);
        day[2]=(Button)findViewById(R.id.day3);
        day[3]=(Button)findViewById(R.id.day4);
        day[4]=(Button)findViewById(R.id.day5);
        day[5]=(Button)findViewById(R.id.day6);
        day[6]=(Button)findViewById(R.id.day7);

        day[0].setOnClickListener(this);
        day[1].setOnClickListener(this);
        day[2].setOnClickListener(this);
        day[3].setOnClickListener(this);
        day[4].setOnClickListener(this);
        day[5].setOnClickListener(this);
        day[6].setOnClickListener(this);

        edit=(EditText)findViewById(R.id.date);

        txt=new TextView[6];
        txt[0]=(TextView)findViewById(R.id.water_status);
        txt[1]=(TextView)findViewById(R.id.hole_status);
        txt[2]=(TextView)findViewById(R.id.color_status);
        txt[3]=(TextView)findViewById(R.id.winkle_status);
        txt[4]=(TextView)findViewById(R.id.sebum_status);
        txt[5]=(TextView)findViewById(R.id.dead_cell_status);

        pro=new ProgressBar[6];
        pro[0]=(ProgressBar)findViewById(R.id.progress);
        //pro[0].setProgress(50);

        pro[1]=(ProgressBar)findViewById(R.id.progress2);
        //pro[1].setProgress(50);

        pro[2]=(ProgressBar)findViewById(R.id.progress3);
        //pro[2].setProgress(50);

        pro[3]=(ProgressBar)findViewById(R.id.progress4);
        //pro[3].setProgress(50);

        pro[4]=(ProgressBar)findViewById(R.id.progress5);
        //pro[4].setProgress(50);

        pro[5]=(ProgressBar)findViewById(R.id.progress6);
       // pro[5].setProgress(50);

//        btn2=(Button)findViewById(R.id.del);
//        btn2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell) values(1,2,3,4,5,6);");
//                db.execSQL("delete from "+TABLE_NAME);
//            }
//        });
//
//        btn=(Button)findViewById(R.id.add);
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell,skin_date) values(1,2,3,4,5,6,20160415);");
//            }
//        });

        openDatabase();

        tmp();
        //ProgressDialog.show(MainActivity2.this,"df","fsdf",true);

    }

    void tmp()
    {
//        db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(100,22,33,84,95,86,20150610);");
//        db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(21,72,35,89,25,6,20150610);");
//        db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(91,82,36,29,5,6,20150610);");
//        db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(61,52,3,4,15,6,20150610);");
//        db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(21,5,3,54,5,6,20150610);");
//        db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(21,2,3,4,89,16,20150610);");
    }

    public void onClick(View v){
        switch(v.getId()){
            case R.id.check:
                check_date = edit.getText().toString();
                //Toast.makeText(getApplicationContext(),check_date,Toast.LENGTH_SHORT).show();
                excuteRawQuery();
                break;
            case R.id.day1:
                searchBy_Day(0);
                break;
            case R.id.day2:
                searchBy_Day(6);
                break;
            case R.id.day3:
                searchBy_Day(5);
                break;
            case R.id.day4:
                searchBy_Day(4);
                break;
            case R.id.day5:
                searchBy_Day(3);
                break;
            case R.id.day6:
                searchBy_Day(2);
                break;
            case R.id.day7:
                searchBy_Day(1);
                break;
        }

    }
    public void searchBy_Day(int day)
    {
        Cursor data=db.rawQuery("select * from "+TABLE_NAME +";",null);
        Cursor check;
        int tmp;
        String tmp2;
        char[] tmp3=new char[11];

//        water="수분" + "\r\n";
//        hole = "모공 "+ "\r\n";
//        color="색소" + "\r\n";
//        winkle="주름" + "\r\n";
//        sebum="피지" + "\r\n";
//        dead_cell="각질" + "\r\n";
//        date="날짜"+"\r\n";


        int[] sum=new int[6];
        sum[0]=0;
        sum[1]=0;
        sum[2]=0;
        sum[3]=0;
        sum[4]=0;
        sum[5]=0;
        int count=0;




        try {
            while (data.moveToNext()) {
                tmp = data.getInt(7);
                tmp2 = String.valueOf(tmp);
                for (int i = 0; i < 8; i++)
                    tmp3[i] = tmp2.charAt(i);

                tmp2 = "";
                for (int i = 0; i < 4; i++)
                    tmp2 += tmp3[i];
                tmp2 += '-';
                for (int i = 4; i < 6; i++)
                    tmp2 += tmp3[i];
                tmp2 += '-';
                for (int i = 6; i < 8; i++)
                    tmp2 += tmp3[i];

                check = db.rawQuery("select strftime('%w', " + tmp2 + ");", null);
                check.moveToNext();
                if (day == check.getInt(0)) {
                    count++;

                    sum[0] += Integer.parseInt(data.getString(1));
                    sum[1] += Integer.parseInt(data.getString(2));
                    sum[2] += Integer.parseInt(data.getString(3));
                    sum[3] += Integer.parseInt(data.getString(4));
                    sum[4] += Integer.parseInt(data.getString(5));
                    sum[5] += Integer.parseInt(data.getString(6));

                }

            }

            if (count == 0)
                count = 1;

        pro[0].setProgress(sum[0]/count);
        pro[1].setProgress(sum[1] / count);
        pro[2].setProgress(sum[2] / count);
        pro[3].setProgress(sum[3] / count);
        pro[4].setProgress(sum[4] / count);
        pro[5].setProgress(sum[5] / count);

        txt[0].setText(String.valueOf(sum[0]/count));
        txt[1].setText(String.valueOf(sum[1]/count));
        txt[2].setText(String.valueOf(sum[2]/count));
        txt[3].setText(String.valueOf(sum[3]/count));
        txt[4].setText(String.valueOf(sum[4]/count));
        txt[5].setText(String.valueOf(sum[5]/count));

            data.close();

        }catch(Exception e)
        {
            e.printStackTrace();
            pro[0].setProgress(0);
            pro[1].setProgress(0);
            pro[2].setProgress(0);
            pro[3].setProgress(0);
            pro[4].setProgress(0);
            pro[5].setProgress(0);

            Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }


    }

    private void openDatabase(){
        dbHelper=new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();
        //generate();
    }
    private void excuteRawQuery(){

        Cursor c1 = db.rawQuery("select * from "+TABLE_NAME +";",null);

        //Cursor c1 = db.rawQuery("select water, skin_date, to_char(skin_date, 'day') day from "+TABLE_NAME + " order by to_char(skin_date, 'd'); ", null);

//        Toast.makeText(getApplication(),"go",Toast.LENGTH_SHORT).show();

//        water="수분" + "\r\n";
//        hole = "모공 "+ "\r\n";
//        color="색소" + "\r\n";
//        winkle="주름" + "\r\n";
//        sebum="피지" + "\r\n";
//        dead_cell="각질" + "\r\n";
//        date="날짜"+"\r\n";


        //Toast.makeText(getApplicationContext(),String.valueOf(c1.getString(7)),Toast.LENGTH_SHORT).show();

        int[] sum=new int[6];
        sum[0]=0;
        sum[1]=0;
        sum[2]=0;
        sum[3]=0;
        sum[4]=0;
        sum[5]=0;
        int count=0;


        try {
            while (c1.moveToNext()) {
                if (c1.getInt(7) == Integer.parseInt(check_date)) {
                    count++;

                    sum[0] += Integer.parseInt(c1.getString(1));
                    sum[1] += Integer.parseInt(c1.getString(2));
                    sum[2] += Integer.parseInt(c1.getString(3));
                    sum[3] += Integer.parseInt(c1.getString(4));
                    sum[4] += Integer.parseInt(c1.getString(5));
                    sum[5] += Integer.parseInt(c1.getString(6));
                }
            }

            if (count == 0)
                count = 1;

        pro[0].setProgress(sum[0]/count);
        pro[1].setProgress(sum[1]/count);
        pro[2].setProgress(sum[2]/count);
        pro[3].setProgress(sum[3]/count);
        pro[4].setProgress(sum[4]/count);
        pro[5].setProgress(sum[5]/count);

        txt[0].setText(String.valueOf(sum[0]/count));
        txt[1].setText(String.valueOf(sum[1]/count));
        txt[2].setText(String.valueOf(sum[2]/count));
        txt[3].setText(String.valueOf(sum[3]/count));
        txt[4].setText(String.valueOf(sum[4]/count));
        txt[5].setText(String.valueOf(sum[5]/count));


            c1.close();
        }catch (Exception e){
            e.printStackTrace();
            pro[0].setProgress(0);
            pro[1].setProgress(0);
            pro[2].setProgress(0);
            pro[3].setProgress(0);
            pro[4].setProgress(0);
            pro[5].setProgress(0);

            Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }

    }

    private void generate()
    {
        String CREATE_SQL = "create table "+TABLE_NAME+"("
                +" _id integer PRIMARY KEY autoincrement,"
                +" water integer,"
                +" hole integer,"
                +" color integer,"
                +" winkle integer,"
                +" sebum integer,"
                +" dead_cell integer,"
                +" skin_date int);";


        try{
            //       String DROP_SQL="drop table if exists "+TABLE_NAME;
            //        db.execSQL(DROP_SQL);

            // db.execSQL(CREATE_SQL);
            Toast.makeText(getApplicationContext(),"fd",Toast.LENGTH_SHORT).show();
        }catch(Exception ex){
            Log.e("main", "exception in CREATE_SQL", ex);
        }

        try{

          //  db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell, skin_date) values(1,2,3,4,5,6,20150609);");
            //db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell) values(1,2,3,4,5,6);");
            //db.execSQL("insert into "+ TABLE_NAME + "(water, hole, color, winkle, sebum, dead_cell) values(1,2,3,4,5,6);");
            Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
        }catch (Exception ex){
            Toast.makeText(getApplicationContext(),"fail",Toast.LENGTH_SHORT).show();
            Log.e("Main","exception in insert SQL",ex);
        }
    }



    public class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context){
            super(context, DATABASE_NAME, null, 1);
        }

        public void onCreate(SQLiteDatabase db){

            try{
               String DROP_SQL="drop table if exists"+TABLE_NAME;

                db.execSQL(DROP_SQL);
                Toast.makeText(getApplication(),"test0",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){
                Log.e("Main","exception in DROP_SQL",ex);
            }
        }
        public void onOpen(SQLiteDatabase db){
    //        Toast.makeText(getApplicationContext(),"open",Toast.LENGTH_SHORT).show();
  //          String DROP_SQL="drop table "+TABLE_NAME+";";
//            db.execSQL(DROP_SQL);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

        }
    }


}
