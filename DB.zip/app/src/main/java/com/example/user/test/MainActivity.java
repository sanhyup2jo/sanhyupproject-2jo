//package com.example.user.test;
//
//import android.database.sqlite.SQLiteDatabase;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//
//public class MainActivity extends AppCompatActivity{
//
//    Button[] btn;
//    EditText[] txt;
//    boolean databaseCreated;
//    boolean tableCreated;
//
//
//    SQLiteDatabase db;
//    TextView tx;
//
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        init();
//    }
//
//    void init()
//    {
//        btn=new Button[2];
//        btn[0]=(Button)findViewById(R.id.create);
//        btn[1]=(Button)findViewById(R.id.create2);
//
//        txt=new EditText[2];
//        txt[0]=(EditText)findViewById(R.id.database);
//        txt[1]=(EditText)findViewById(R.id.table);
//
//
//        btn[0].setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String databaseName = txt[0].getText().toString();
//                createDatabase(databaseName);
//            }
//        });
//        btn[1].setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String tableNmae=txt[1].getText().toString();
//                createTable(tableNmae);
//                int count=insertRecord(tableNmae);
//                println(count + " records inserted");
//            }
//        });
//
//
//        tx=(TextView)findViewById(R.id.status);
//    }
//
//    private void createDatabase(String name){
//        println("creating database [" + name + "].");
//
//        try{
//            db=openOrCreateDatabase(name, MODE_WORLD_WRITEABLE, null);
//            databaseCreated=true;
//            println("databse is created");
//        }catch (Exception ex){
//            ex.printStackTrace();
//            println("database is not created");
//        }
//    }
//
//    private void createTable(String name){
//        println("create table ["+name+ "].");
//
//        db.execSQL("create table "+name+"("+" _id integer PRIMARY KEY autoincrement, "
//        +" name text, "
//        +" age integer, "
//        +" phone text);" );
//
//
//        tableCreated=true;
//    }
//
//    private int insertRecord(String name){
//        println("inserting records into table " + name + ".");
//
//        int count=3;
//        db.execSQL("insert into "+name+"(name, age, phone) values ('John', 20, '010-7786-1234');");
//
//        return count;
//    }
//
//    public void println(String str)
//    {
//        tx.setText(tx.getText().toString() + "\n" + str);
//    }
//}
